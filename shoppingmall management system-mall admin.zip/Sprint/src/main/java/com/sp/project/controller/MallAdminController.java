package com.sp.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sp.project.entity.MallAdmin;
import com.sp.project.service.MallAdminService;

@RestController
public class MallAdminController {

	@Autowired
	MallAdminService m1;
	@PostMapping("/MallAdmin")
	public MallAdmin saveMallAdmin(@RequestBody MallAdmin mallAdmin) {
    	
    	return m1.saveMallAdmin(mallAdmin);
		
	}
 
 @GetMapping("/MallAdmin")
    public List<MallAdmin> fetchMallAdminList() {
        //LOGGER.info("Inside fetchDepartmentList of DepartmentController");
        return m1.fetchMallAdminList();
    }
 
 @GetMapping("/MallAdmin/{id}")
    public MallAdmin fetchMallAdminById(@PathVariable("id") Long id)
            {
        return m1.fetchMallAdminById(id);
    }
    
 @DeleteMapping("/MallAdmin/{id}")
    public String deleteMallAdminById(@PathVariable("id") Long id) {
	 m1.deleteMallAdminById(id);
        return "Department deleted Successfully!!";
    }




}
