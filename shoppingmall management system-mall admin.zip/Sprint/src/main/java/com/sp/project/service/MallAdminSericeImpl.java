package com.sp.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sp.project.entity.MallAdmin;
import com.sp.project.repository.MallAdminRepository;

@Service
public class MallAdminSericeImpl implements MallAdminService{

	@Autowired
	MallAdminRepository mr;
	@Override
	public MallAdmin saveMallAdmin(MallAdmin mallAdmin) {
		// TODO Auto-generated method stub
		return mr.save(mallAdmin);
	}

	@Override
	public List<MallAdmin> fetchMallAdminList() {
		// TODO Auto-generated method stub
		return mr.findAll();
	}

	@Override
	public MallAdmin fetchMallAdminById(Long id) {
		// TODO Auto-generated method stub
		return mr.findById(id).get();
	}

	@Override
	public void deleteMallAdminById(Long id) {
		// TODO Auto-generated method stub
		mr.deleteById(id);
	}

}
