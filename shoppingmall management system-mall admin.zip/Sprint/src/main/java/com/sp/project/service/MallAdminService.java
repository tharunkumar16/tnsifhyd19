package com.sp.project.service;

import com.sp.project.entity.MallAdmin;

public interface MallAdminService {

	MallAdmin saveMallAdmin(MallAdmin mallAdmin);

	java.util.List<MallAdmin> fetchMallAdminList();

	MallAdmin fetchMallAdminById(Long id);

	void deleteMallAdminById(Long id);

	

}
